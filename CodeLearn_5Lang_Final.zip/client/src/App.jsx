import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import HomePage from './pages/HomePage'
import CPage from './pages/CPage'
import CppPage from './pages/CppPage'
import JavaPage from './pages/JavaPage'
import PythonPage from './pages/PythonPage'
import JsPage from './pages/JsPage'
import FeedbackPage from './pages/FeedbackPage'
import AboutPage from './pages/AboutPage'
import ContactPage from './pages/ContactPage'

export default function App(){
  return (
    <div>
      <Header />
      <main className="main">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/c" element={<CPage />} />
          <Route path="/cpp" element={<CppPage />} />
          <Route path="/java" element={<JavaPage />} />
          <Route path="/python" element={<PythonPage />} />
          <Route path="/javascript" element={<JsPage />} />
          <Route path="/feedback" element={<FeedbackPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
        </Routes>
      </main>
      <Footer />
    </div>
  )
}
