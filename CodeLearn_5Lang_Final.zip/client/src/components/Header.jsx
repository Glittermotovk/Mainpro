import React from 'react'
import { NavLink } from 'react-router-dom'

export default function Header(){
  return (
    <header className="header">
      <div className="header-inner">
        <div className="logo">CodeLearn</div>
        <nav className="nav">
          <NavLink to="/" end>Home</NavLink>
          <NavLink to="/about">About</NavLink>
          <NavLink to="/feedback">Feedback</NavLink>
          <NavLink to="/contact">Contact</NavLink>
        </nav>
      </div>
    </header>
  )
}
