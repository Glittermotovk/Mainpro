import React from 'react'

export default function ContactPage(){
  return (
    <div>
      <h2>Contact</h2>
      <p>For any questions about this project, you can put your college email or phone here.</p>
    </div>
  )
}
