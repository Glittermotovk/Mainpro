import React, { useState } from 'react'
import axios from 'axios'
import { API_URL } from '../config'

export default function FeedbackPage(){
  const [name,setName] = useState('')
  const [email,setEmail] = useState('')
  const [message,setMessage] = useState('')
  const [status,setStatus] = useState('')

  const submit = async (e)=>{
    e.preventDefault()
    try{
      await axios.post(`${API_URL}/api/feedback/`, { name, email, message })
      setStatus('Thanks! Feedback saved.')
      setName(''); setEmail(''); setMessage('')
    }catch(err){
      console.error(err)
      setStatus('Error sending feedback. Check server.')
    }
  }

  return (
    <div className="form">
      <h2>Feedback</h2>
      <p>We value your feedback — it helps us improve.</p>
      <form onSubmit={submit}>
        <input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" required />
        <input value={email} onChange={e=>setEmail(e.target.value)} placeholder="Your email" type="email" required />
        <textarea value={message} onChange={e=>setMessage(e.target.value)} placeholder="Your message" rows={6} required />
        <button className="btn" type="submit">Send Feedback</button>
      </form>
      <p style={{marginTop:10}}>{status}</p>
    </div>
  )
}
