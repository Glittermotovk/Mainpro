import React, { useState } from 'react'

const topics = [
  'Introduction',
  'Variables',
  'Data Types',
  'Operators',
  'If-Else',
  'Loops',
  'Functions',
  'Arrays',
  'Pointers',
  'Strings',
]

export default function JsPage(){{
  const [active, setActive] = useState('Introduction')

  return (
    <div className="lang-layout">
      <aside className="sidebar">
        <div className="sidebar-title">Topics</div>
        {topics.map(tp => (
          <div
            key={tp}
            className={'topic ' + (tp === active ? 'active' : '')}
            onClick={() => setActive(tp)}
          >
            {tp}
          </div>
        ))}
      </aside>
      <section className="lang-content">
        <h1>JavaScript Language</h1>
        <div className="lang-sub">Variables are used to store values in memory.</div>
        <p className="lang-desc">JavaScript runs in the browser and on servers with Node.js.</p>

        <h3>Example</h3>
        <pre className="codebox">{`let x = 10;
console.log(x);`}</pre>

        <h3>Output</h3>
        <div className="output-box">10</div>
      </section>
    </div>
  )
}}
