import React, { useState } from 'react'

const topics = [
  'Introduction',
  'Variables',
  'Data Types',
  'Operators',
  'If-Else',
  'Loops',
  'Functions',
  'Arrays',
  'Pointers',
  'Strings',
]

export default function CppPage(){{
  const [active, setActive] = useState('Introduction')

  return (
    <div className="lang-layout">
      <aside className="sidebar">
        <div className="sidebar-title">Topics</div>
        {topics.map(tp => (
          <div
            key={tp}
            className={'topic ' + (tp === active ? 'active' : '')}
            onClick={() => setActive(tp)}
          >
            {tp}
          </div>
        ))}
      </aside>
      <section className="lang-content">
        <h1>C++ Language</h1>
        <div className="lang-sub">Variables are used to store values in memory.</div>
        <p className="lang-desc">C++ extends C with objects, classes and many high level features.</p>

        <h3>Example</h3>
        <pre className="codebox">{`#include <iostream>
using namespace std;

int main() {
  int x = 10;
  cout << x;
  return 0;
}`}</pre>

        <h3>Output</h3>
        <div className="output-box">10</div>
      </section>
    </div>
  )
}}
