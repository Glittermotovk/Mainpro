import React from 'react'
import { useNavigate } from 'react-router-dom'

export default function HomePage(){
  const nav = useNavigate()

  const cards = [
    { id:'c', label:'C', sub:'C Language', color:'#2563eb' },
    { id:'cpp', label:'C++', sub:'C++ Language', color:'#0f766e' },
    { id:'java', label:'Java', sub:'Java Programming', color:'#dc2626' },
    { id:'python', label:'Python', sub:'Python Language', color:'#f59e0b' },
    { id:'javascript', label:'JavaScript', sub:'JavaScript Language', color:'#22c55e' },
  ]

  return (
    <>
      <div className="hero">
        <h1>Welcome to CodeLearn</h1>
        <p>
          Learn programming languages with clean explanations, examples and real project-based
          learning — just like W3Schools but in your own style.
        </p>
      </div>

      <section className="section">
        <h2>Choose a Language</h2>
        <div className="lang-grid">
          {cards.map(card => (
            <div
              key={card.id}
              className="lang-card"
              style={{ background: card.color }}
              onClick={() => nav('/' + card.id)}
            >
              <div style={{ fontSize:32 }}>{card.label}</div>
              <small>{card.sub}</small>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <h2>Why Choose CodeLearn?</h2>
        <div className="info-grid">
          <div className="info-card">
            <div className="info-title">Easy Explanations</div>
            <div className="info-text">Each topic is broken down in the simplest way with examples.</div>
          </div>
          <div className="info-card">
            <div className="info-title">Fast Learning</div>
            <div className="info-text">Clean notes and highlighted code blocks help you learn faster.</div>
          </div>
          <div className="info-card">
            <div className="info-title">Real Examples</div>
            <div className="info-text">Every topic comes with real code examples you can run.</div>
          </div>
          <div className="info-card">
            <div className="info-title">Fully Responsive</div>
            <div className="info-text">Works beautifully on mobile, tablet and desktop.</div>
          </div>
        </div>
      </section>
    </>
  )
}
