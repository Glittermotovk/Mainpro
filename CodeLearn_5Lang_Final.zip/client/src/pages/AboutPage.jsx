import React from 'react'

export default function AboutPage(){
  return (
    <div>
      <h2>About CodeLearn</h2>
      <p>
        CodeLearn is a mini learning portal inspired by W3Schools. It focuses on 5 core languages:
        C, C++, Java, Python and JavaScript — with clean examples and simple notes.
      </p>
    </div>
  )
}
