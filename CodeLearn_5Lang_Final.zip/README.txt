CodeLearn 5 Languages FullStack Project

Backend (server):
  cd server
  python -m venv venv
  venv\Scripts\activate
  pip install -r requirements.txt

  MySQL:
    CREATE DATABASE codelearn_db;

  .env.example ko copy karke .env banao
    DB_PASS me apna MySQL password daalo

  python manage.py migrate
  python manage.py runserver 0.0.0.0:4000

Frontend (client):
  cd client
  npm install
  npm run dev

Browser:
  Frontend: http://localhost:5173
  API test: POST http://localhost:4000/api/feedback/
